let audio = new Audio();
let currentIndex = 0;

// Songs list (15 tracks)
let songs = [
  { title: "Faded", artist: "Alan Walker", file: "music/Faded.mp3", image: "images/faded.png" },
  { title: "Falling Down", artist: "XXXTentacion & Lil Peep", file: "music/fallingdown.mp3", image: "images/stay.png" },
  { title: "Rather Be", artist: "Clean Bandit ft. Jess Glynne", file: "music/Rather Be.mp3", image: "images/ratherbe.jpg" },
  { title: "Stay", artist: "The Kid LAROI & Justin Bieber", file: "music/stay.mp3", image: "images/stay.png" },
  { title: "Shape of You", artist: "Ed Sheeran", file: "music/shapeofyou.mp3", image: "images/shapeofyou.jpeg" },
  { title: "Blinding Lights", artist: "The Weeknd", file: "music/blindinglights.mp3", image: "images/blindinglights.jpeg" },
  { title: "Levitating", artist: "Dua Lipa", file: "music/levitating.mp3", image: "images/levitating.jpeg" },
  { title: "Peaches", artist: "Justin Bieber ft. Daniel Caesar, Giveon", file: "music/peaches.mp3", image: "images/peaches.jpeg" },
  { title: "Heat Waves", artist: "Glass Animals", file: "music/heatwaves.mp3", image: "images/heatwaves.jpeg" },
  { title: "Sunflower", artist: "Post Malone & Swae Lee", file: "music/sunflower.mp3", image: "images/sunflower.jpeg" },
  { title: "Perfect", artist: "Ed Sheeran", file: "music/perfect.mp3", image: "images/perfect.jpeg" },
  { title: "Bad Guy", artist: "Billie Eilish", file: "music/badguy.mp3", image: "images/badguy.jpeg" },
  { title: "Senorita", artist: "Shawn Mendes & Camila Cabello", file: "music/senorita.mp3", image: "images/senorita.jpeg" },
  { title: "Happier", artist: "Marshmello ft. Bastille", file: "music/happier.mp3", image: "images/happier.jpeg" },
  { title: "Believer", artist: "Imagine Dragons", file: "music/believer.mp3", image: "images/believer.jpeg" }
];

let recentlyPlayed = JSON.parse(localStorage.getItem("recentlyPlayed")) || [];
let favorites = JSON.parse(localStorage.getItem("favorites")) || [];

// Initialize
renderPlaylist(songs);
loadSong(0);

// Load a song
function loadSong(index) {
  currentIndex = index;
  let song = songs[index];
  audio.src = song.file;
  document.getElementById("track-name").innerText = song.title;
  document.getElementById("track-artist").innerText = song.artist;
  document.getElementById("track-art").style.backgroundImage = `url('${song.image}')`;
  document.getElementById("nowIndex").innerText = index + 1;
  document.getElementById("nowTotal").innerText = songs.length;

  // update favorite star in "Now Playing"
  let favNowBtn = document.getElementById("favNowBtn");
  if (favNowBtn) {
    favNowBtn.innerText = favorites.find(s => s.title === song.title) ? "★" : "☆";
    favNowBtn.onclick = () => {
      toggleFavorite(song);
      favNowBtn.innerText = favorites.find(s => s.title === song.title) ? "★" : "☆";
      renderPlaylist(songs);
    };
  }

  highlightActiveSong();
}

// Play/Pause
document.getElementById("playpauseBtn").addEventListener("click", () => {
  if (audio.paused) {
    audio.play();
    document.getElementById("playIcon").classList.replace("fa-play-circle", "fa-pause-circle");
  } else {
    audio.pause();
    document.getElementById("playIcon").classList.replace("fa-pause-circle", "fa-play-circle");
  }
});

// Next/Prev
document.getElementById("nextBtn").addEventListener("click", () => {
  currentIndex = (currentIndex + 1) % songs.length;
  loadSong(currentIndex);
  audio.play();
});
document.getElementById("prevBtn").addEventListener("click", () => {
  currentIndex = (currentIndex - 1 + songs.length) % songs.length;
  loadSong(currentIndex);
  audio.play();
});

// Autoplay next
audio.addEventListener("ended", () => {
  currentIndex = (currentIndex + 1) % songs.length;
  loadSong(currentIndex);
  audio.play();
});

// Update Seek Bar
audio.addEventListener("timeupdate", () => {
  let seek = document.getElementById("seek_slider");
  seek.max = audio.duration || 0;
  seek.value = audio.currentTime;
  document.getElementById("curr_time").innerText = formatTime(audio.currentTime);
  document.getElementById("total_duration").innerText = formatTime(audio.duration);
});
document.getElementById("seek_slider").addEventListener("input", e => {
  audio.currentTime = e.target.value;
});

// Volume
document.getElementById("volume_slider").addEventListener("input", e => {
  audio.volume = e.target.value / 100;
});

// Format Time
function formatTime(sec) {
  if (isNaN(sec)) return "00:00";
  let m = Math.floor(sec / 60);
  let s = Math.floor(sec % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

// Render Playlist with favorite stars
function renderPlaylist(songs) {
  let playlist = document.getElementById("playlist");
  playlist.innerHTML = "";
  songs.forEach((song, i) => {
    let li = document.createElement("li");
    let star = favorites.find(s => s.title === song.title) ? "★" : "☆";
    li.innerHTML = `${song.title} - ${song.artist} <button class="favBtn">${star}</button>`;
    li.querySelector(".favBtn").onclick = (e) => {
      e.stopPropagation();
      toggleFavorite(song);
      renderPlaylist(songs);
      loadSong(currentIndex); // update Now Playing star
    };
    li.onclick = () => {
      loadSong(i);
      audio.play();
      saveRecentlyPlayed(song);
    };
    playlist.appendChild(li);
  });
  highlightActiveSong();
}

// Highlight active song
function highlightActiveSong() {
  document.querySelectorAll("#playlist li").forEach((li, i) => {
    li.classList.toggle("active", i === currentIndex);
  });
}

// Recently Played
function saveRecentlyPlayed(song) {
  recentlyPlayed.unshift(song);
  recentlyPlayed = [...new Set(recentlyPlayed.map(s => s.title))].map(
    t => recentlyPlayed.find(s => s.title === t)
  );
  recentlyPlayed = recentlyPlayed.slice(0, 5);
  localStorage.setItem("recentlyPlayed", JSON.stringify(recentlyPlayed));
  renderRecentlyPlayed();
}
function renderRecentlyPlayed() {
  let list = document.getElementById("recentlyPlayed");
  list.innerHTML = "";
  recentlyPlayed.forEach(song => {
    let li = document.createElement("li");
    li.innerText = song.title;
    list.appendChild(li);
  });
}
renderRecentlyPlayed();

// Favorites
function toggleFavorite(song) {
  let index = favorites.findIndex(s => s.title === song.title);
  if (index === -1) favorites.push(song);
  else favorites.splice(index, 1);
  localStorage.setItem("favorites", JSON.stringify(favorites));
  renderFavorites();
}
function renderFavorites() {
  let list = document.getElementById("favorites");
  list.innerHTML = "";
  favorites.forEach(song => {
    let li = document.createElement("li");
    li.innerHTML = `${song.title} <button class="favBtn">★</button>`;
    li.querySelector(".favBtn").onclick = () => {
      toggleFavorite(song);
      renderPlaylist(songs);
      loadSong(currentIndex); // update Now Playing star
    };
    list.appendChild(li);
  });
}
renderFavorites();

// Search
document.getElementById("search").addEventListener("input", e => {
  let term = e.target.value.toLowerCase();
  let filtered = songs.filter(s => s.title.toLowerCase().includes(term));
  renderPlaylist(filtered);
});
